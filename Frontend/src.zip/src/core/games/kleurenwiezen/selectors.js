import { getKleurenwiezenContract } from "./contracts";
import { getCalculatedStarterSeat, getEffectiveTargetTricks } from "./helpers";

export function getTrumpLabel(suit) {
  switch (String(suit ?? "").toUpperCase()) {
    case "H":
      return "♥ Harten";
    case "D":
      return "♦ Ruiten";
    case "C":
      return "♣ Klaveren";
    case "S":
      return "♠ Schoppen";
    default:
      return "Geen troef";
  }
}

export function getContractLabel(contractId) {
  return getKleurenwiezenContract(contractId)?.label ?? "—";
}

export function getTrickWinsByPlayer(trickHistory = [], playersCount = 4) {
  const wins = Array(playersCount).fill(0);

  for (const trick of trickHistory ?? []) {
    const winnerIndex = trick?.winnerIndex;

    if (
      typeof winnerIndex === "number" &&
      winnerIndex >= 0 &&
      winnerIndex < playersCount
    ) {
      wins[winnerIndex] += 1;
    }
  }

  return wins;
}

function getDeclarantSeats(slice) {
  if (Array.isArray(slice?.declarantSeats) && slice.declarantSeats.length > 0) {
    return slice.declarantSeats;
  }

  if (typeof slice?.declarantSeat === "number") {
    return [slice.declarantSeat];
  }

  return [];
}

export function getAttackSeatSet(slice) {
  const contract = getKleurenwiezenContract(slice?.contractId);
  const attackSeats = new Set();

  if (contract?.allowMultipleDeclarants) {
    for (const seat of getDeclarantSeats(slice)) {
      if (typeof seat === "number") {
        attackSeats.add(seat);
      }
    }

    return attackSeats;
  }

  if (typeof slice?.declarantSeat === "number") {
    attackSeats.add(slice.declarantSeat);
  }

  if (contract?.needsPartner && typeof slice?.partnerSeat === "number") {
    attackSeats.add(slice.partnerSeat);
  }

  return attackSeats;
}

export function getFriendlyTeamLabel(slice, players = []) {
  const contract = getKleurenwiezenContract(slice?.contractId);
  if (!contract) return "—";

  if (contract.allowMultipleDeclarants) {
    const seats = getDeclarantSeats(slice);

    if (seats.length === 0) {
      return "Nog geen spelers";
    }

    return seats
      .map((seat) => players?.[seat]?.name ?? `Player ${seat + 1}`)
      .join(" + ");
  }

  const declarantName =
    typeof slice?.declarantSeat === "number"
      ? players?.[slice.declarantSeat]?.name ?? `Player ${slice.declarantSeat + 1}`
      : "—";

  if (!contract.needsPartner) {
    return `${declarantName} solo`;
  }

  const partnerName =
    typeof slice?.partnerSeat === "number"
      ? players?.[slice.partnerSeat]?.name ?? `Player ${slice.partnerSeat + 1}`
      : "Nog kiezen";

  return `${declarantName} + ${partnerName}`;
}

export function getTeamTrickSummary(slice, players = []) {
  const contract = getKleurenwiezenContract(slice?.contractId);
  const trickWins = getTrickWinsByPlayer(slice?.trickHistory ?? [], players.length || 4);
  const attackSeats = getAttackSeatSet(slice);

  let attackTricks = 0;
  let defenseTricks = 0;

  trickWins.forEach((count, index) => {
    if (attackSeats.has(index)) {
      attackTricks += count;
    } else {
      defenseTricks += count;
    }
  });

  return {
    attackLabel: getFriendlyTeamLabel(slice, players),
    defenseLabel: contract?.needsPartner ? "Tegenpartij" : "Rest van de tafel",
    attackTricks,
    defenseTricks,
  };
}

function getSuccessPoints(contract, actualAttackTricks, targetTricks, slice) {
  if (Array.isArray(contract.successScores) && contract.successScores.length > 0) {
    const index = Math.max(
      0,
      Math.min(contract.successScores.length - 1, actualAttackTricks - targetTricks)
    );

    return contract.successScores[index];
  }

  return contract.successPoints ?? 0;
}

function getFailPlayersPoints(contract, actualAttackTricks, targetTricks) {
  if (typeof contract.failPlayersPoints === "number") {
    return contract.failPlayersPoints;
  }

  const under = Math.max(1, targetTricks - actualAttackTricks);
  const value = (contract.failStart ?? 0) + (under - 1) * (contract.failStep ?? 0);
  const limited = typeof contract.failMax === "number" ? Math.min(contract.failMax, value) : value;

  return -limited;
}

function getFailOppPoints(contract, actualAttackTricks, targetTricks) {
  if (typeof contract.failOppPoints === "number") {
    return contract.failOppPoints;
  }

  const under = Math.max(1, targetTricks - actualAttackTricks);
  const value = (contract.failOppBase ?? 0) + (under - 1) * (contract.failOppStep ?? 0);

  return typeof contract.failOppMax === "number" ? Math.min(contract.failOppMax, value) : value;
}

function applyMiseriePiccoloTableScore({ contract, slice, playersCount }) {
  const playerDeltas = Array(playersCount).fill(0);
  const declarantSeats = getDeclarantSeats(slice);
  const declarantSet = new Set(declarantSeats);
  const trickWinsByPlayer = getTrickWinsByPlayer(slice?.trickHistory ?? [], playersCount);

  let failedDeclarants = 0;

  for (const seat of declarantSeats) {
    const tricksWon = trickWinsByPlayer[seat] ?? 0;

    const succeeded =
      contract.targetType === "exact"
        ? tricksWon === contract.targetTricks
        : tricksWon >= contract.targetTricks;

    if (succeeded) {
      playerDeltas[seat] += contract.successPoints ?? 0;
    } else {
      playerDeltas[seat] += contract.failPlayersPoints ?? 0;
      failedDeclarants += 1;
    }
  }

  const opponentGain = (contract.failOppPoints ?? 0) * failedDeclarants;

  for (let i = 0; i < playersCount; i += 1) {
    if (!declarantSet.has(i)) {
      playerDeltas[i] += opponentGain;
    }
  }

  return {
    playerDeltas,
    failedDeclarants,
    success: failedDeclarants === 0,
  };
}

export function evaluateRound(slice, players = []) {
  const contract = getKleurenwiezenContract(slice?.contractId);
  const teamSummary = getTeamTrickSummary(slice, players);
  const targetTricks = getEffectiveTargetTricks(slice);
  const starterSeat = getCalculatedStarterSeat(slice, players.length || 4);

  if (!contract || targetTricks == null) {
    return {
      success: null,
      targetLabel: "—",
      resultLabel: "Nog geen contract geselecteerd",
      attackPoints: 0,
      defensePoints: 0,
      playerDeltas: Array(players.length || 4).fill(0),
      starterSeat,
      ...teamSummary,
    };
  }

  const actual = teamSummary.attackTricks;
  const success = contract.targetType === "exact" ? actual === targetTricks : actual >= targetTricks;
  const comparisonWord = contract.targetType === "exact" ? "exact" : "minstens";
  const attackSeats = getAttackSeatSet(slice);
  const playerCount = players.length || 4;
  const playerDeltas = Array(playerCount).fill(0);

  let attackPoints = 0;
  let defensePoints = 0;

  if (contract.scoringType === "miseriePiccoloTable") {
    const result = applyMiseriePiccoloTableScore({
      contract,
      slice,
      playersCount: playerCount,
    });

    return {
      success: result.success,
      targetTricks,
      targetLabel: `${comparisonWord} ${targetTricks} slagen`,
      resultLabel: result.success ? "Contract gehaald" : "Contract niet gehaald",
      attackPoints: contract.successPoints ?? 0,
      defensePoints: contract.failOppPoints ?? 0,
      playerDeltas: result.playerDeltas,
      starterSeat,
      ...teamSummary,
    };
  }

  if (contract.scoringType === "troelTable") {
    let troelScore = 0;
    let opponentScore = 15;

    if (actual === 13) {
      troelScore = contract.bonusAllTricksPoints ?? 30;
      opponentScore = 0;
    } else if (actual >= 9) {
      troelScore = contract.successPoints ?? 15;
      opponentScore = 0;
    }

    attackPoints = troelScore;
    defensePoints = opponentScore;

    attackSeats.forEach((seat) => {
      if (seat >= 0 && seat < playerCount) {
        playerDeltas[seat] += troelScore;
      }
    });

    for (let i = 0; i < playerCount; i += 1) {
      if (!attackSeats.has(i)) {
        playerDeltas[i] += opponentScore;
      }
    }
  } else if (contract.scoringType === "pairTable") {
    const pairScore = success
      ? getSuccessPoints(contract, actual, targetTricks, slice)
      : getFailPlayersPoints(contract, actual, targetTricks);

    attackPoints = pairScore;
    defensePoints = -pairScore;

    attackSeats.forEach((seat) => {
      if (seat >= 0 && seat < playerCount) {
        playerDeltas[seat] += pairScore;
      }
    });

    for (let i = 0; i < playerCount; i += 1) {
      if (!attackSeats.has(i)) {
        playerDeltas[i] -= pairScore;
      }
    }
  } else if (contract.scoringType === "soloTable") {
    const soloScore = success
      ? getSuccessPoints(contract, actual, targetTricks, slice)
      : getFailPlayersPoints(contract, actual, targetTricks);

    const opponentScore = success
      ? -Math.abs(soloScore) / 3
      : getFailOppPoints(contract, actual, targetTricks);

    attackPoints = soloScore;
    defensePoints = opponentScore;

    attackSeats.forEach((seat) => {
      if (seat >= 0 && seat < playerCount) {
        playerDeltas[seat] += soloScore;
      }
    });

    for (let i = 0; i < playerCount; i += 1) {
      if (!attackSeats.has(i)) {
        playerDeltas[i] += opponentScore;
      }
    }
  } else if (success) {
    attackPoints = getSuccessPoints(contract, actual, targetTricks, slice);

    attackSeats.forEach((seat) => {
      if (seat >= 0 && seat < playerCount) {
        playerDeltas[seat] += attackPoints;
      }
    });
  } else {
    attackPoints = getFailPlayersPoints(contract, actual, targetTricks);
    defensePoints = getFailOppPoints(contract, actual, targetTricks);

    attackSeats.forEach((seat) => {
      if (seat >= 0 && seat < playerCount) {
        playerDeltas[seat] += attackPoints;
      }
    });

    for (let i = 0; i < playerCount; i += 1) {
      if (!attackSeats.has(i)) {
        playerDeltas[i] += defensePoints;
      }
    }
  }

  return {
    success,
    targetTricks,
    targetLabel: `${comparisonWord} ${targetTricks} slagen`,
    resultLabel: success ? "Contract gehaald" : "Contract niet gehaald",
    attackPoints,
    defensePoints,
    playerDeltas,
    starterSeat,
    ...teamSummary,
  };
}